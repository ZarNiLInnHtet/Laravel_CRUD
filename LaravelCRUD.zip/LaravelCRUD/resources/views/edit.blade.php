@extends('layouts.master')
@section('title', 'Add Post')

@section('contant')
    <div class="container">
        <div class="row">
            <div class="card col-md-9 mx-auto my-5">


                <form method="POST" action="/admin/post/{{ $edit->id }}/edit_post">
                    <h2 class="text-center my-5">Edit Post</h2>
                    @if (session('success'))
                        <div class="alert alert-primary text-center" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif
                    @csrf
                    <div class="form-group">
                        <label for="exampleInputEmail1">Title</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            name="title" value="{{ $edit->title }}" required>
                        @error('title')
                            <p class="text-danger">{{ $message }}</p>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Description</label>

                        <textarea name="description" id="" cols="30" rows="5" class="form-control" required
                            value="{{ old('description') }}">{{ $edit->description }}</textarea>
                        @error('description')
                            <p class="text-danger">{{ $message }}</p>
                        @enderror
                    </div>
                    <div class="mb-5">

                        <button type="submit" class="btn btn-primary ">Edit Post</button>
                        <a href="/admin/post" class="btn btn-success">Admin</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
