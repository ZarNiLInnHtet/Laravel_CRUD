@extends('layouts.master')
@section('title', 'Add Post')

@section('contant')
    <div class="container">
        <div class="row">
            <div class="col-md-12 mx-auto my-5">
                <h2 class="text-center text-primary my-5 ">Admin Dashboard</h2>
                <table class="table">
                    <thead>
                        <tr>

                            <th scope="col">Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($posts as $post)
                            <tr>

                                <td>{{ $post->title }}</td>
                                <td>{{ $post->description }}</td>

                                <td>
                                    <a href="/admin/post/{{ $post->id }}/delete " class="btn btn-danger">Delete</a>
                                    <a href="/admin/post/{{ $post->id }}/edit " class="btn btn-warning">Edit</a>

                                </td>

                            </tr>
                        @endforeach

                        {{-- /admin/post/{{ $post->id }}/delete --}}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
