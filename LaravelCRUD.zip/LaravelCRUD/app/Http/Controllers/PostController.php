<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function index()
    {
        return view('index');
    }
    public function store()
    {
        $formData = request()->validate([
            'title' => 'required',
            'description' => 'required'
        ]);
        Post::create($formData);
        return redirect('/')->with('success', 'Add Post is Successful');
    }

    public function post()
    {
        return view('admin', [
            'posts' => Post::all(),
        ]);
    }
    public function destory($id)
    {
        Post::destroy($id);
        return back();
    }
    public function edit($id)
    {
        return view('edit', [
            'edit' => Post::find($id)
        ]);
    }
    public function edit_post($id)
    {
        $formData = request()->validate([
            'title' => 'required',
            'description' => 'required'
        ]);
        Post::find($id)->update($formData);
        return redirect('/admin/post');
    }
}
