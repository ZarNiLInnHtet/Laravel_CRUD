<?php

use App\Http\Controllers\PostController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [PostController::class, 'index']);
Route::post('/', [PostController::class, 'store']);

Route::get('/admin/post', [PostController::class, 'post']);
Route::get('/admin/post/{id}/delete', [PostController::class, 'destory']);

Route::get('/admin/post/{id}/edit', [PostController::class, 'edit']);
Route::post('/admin/post/{id}/edit_post', [PostController::class, 'edit_post']);
