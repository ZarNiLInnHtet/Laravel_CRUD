<?php $__env->startSection('title', 'Add Post'); ?>

<?php $__env->startSection('contant'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mx-auto my-5">
                <h2 class="text-center text-primary my-5 ">Admin Dashboard</h2>
                <table class="table">
                    <thead>
                        <tr>

                            <th scope="col">Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($post->title); ?></td>
                                <td><?php echo e($post->description); ?></td>

                                <td>
                                    <a href="/admin/post/<?php echo e($post->id); ?>/delete " class="btn btn-danger">Delete</a>
                                    <a href="/admin/post/<?php echo e($post->id); ?>/edit " class="btn btn-warning">Edit</a>

                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\LaravelCRUD\resources\views/admin.blade.php ENDPATH**/ ?>