<?php $__env->startSection('title', 'Add Post'); ?>

<?php $__env->startSection('contant'); ?>
    <div class="container">
        <div class="row">
            <div class="card col-md-9 mx-auto my-5">


                <form method="POST" action="/admin/post/<?php echo e($edit->id); ?>/edit_post">
                    <h2 class="text-center my-5">Edit Post</h2>
                    <?php if(session('success')): ?>
                        <div class="alert alert-primary text-center" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Title</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            name="title" value="<?php echo e($edit->title); ?>" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Description</label>

                        <textarea name="description" id="" cols="30" rows="5" class="form-control" required
                            value="<?php echo e(old('description')); ?>"><?php echo e($edit->description); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-5">

                        <button type="submit" class="btn btn-primary ">Edit Post</button>
                        <a href="/admin/post" class="btn btn-success">Admin</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\LaravelCRUD\resources\views/edit.blade.php ENDPATH**/ ?>